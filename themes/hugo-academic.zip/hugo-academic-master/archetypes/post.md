+++
title = "{{ replace .TranslationBaseName "-" " " | title }}"
date = "{{ .Date }}"

math = false
highlight = true
tags = []

# Optional featured image (relative to `static/img/` folder).
[header]
image = ""
caption = ""

+++
